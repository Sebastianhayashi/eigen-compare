# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tvmet
# Build directory: /home/cody/Sebastianlin/eigen-3.4.0/build-official/libs/tvmet
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
