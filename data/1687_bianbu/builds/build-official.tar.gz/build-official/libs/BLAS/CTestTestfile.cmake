# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/BLAS
# Build directory: /home/cody/Sebastianlin/eigen-3.4.0/build-official/libs/BLAS
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(btl_openblas "btl_openblas")
set_tests_properties(btl_openblas PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/BLAS/CMakeLists.txt;23;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/BLAS/CMakeLists.txt;0;")
