# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3
# Build directory: /home/cody/Sebastianlin/eigen-3.4.0/build-official/libs/eigen3
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(btl_eigen3_linear "btl_eigen3_linear")
set_tests_properties(btl_eigen3_linear PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;14;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;0;")
add_test(btl_eigen3_vecmat "btl_eigen3_vecmat")
set_tests_properties(btl_eigen3_vecmat PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;15;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;0;")
add_test(btl_eigen3_matmat "btl_eigen3_matmat")
set_tests_properties(btl_eigen3_matmat PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;16;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;0;")
add_test(btl_eigen3_adv "btl_eigen3_adv")
set_tests_properties(btl_eigen3_adv PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;17;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/eigen3/CMakeLists.txt;0;")
