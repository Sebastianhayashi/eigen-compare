# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors
# Build directory: /home/cody/Sebastianlin/eigen-3.4.0/build-official/libs/tensors
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(btl_tensor_linear "btl_tensor_linear")
set_tests_properties(btl_tensor_linear PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;14;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;0;")
add_test(btl_tensor_vecmat "btl_tensor_vecmat")
set_tests_properties(btl_tensor_vecmat PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;15;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;0;")
add_test(btl_tensor_matmat "btl_tensor_matmat")
set_tests_properties(btl_tensor_matmat PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;16;btl_add_bench;/home/cody/Sebastianlin/eigen-3.4.0/bench/btl/libs/tensors/CMakeLists.txt;0;")
