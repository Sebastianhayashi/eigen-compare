# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-rvv/bench/btl
# Build directory: /home/cody/Sebastianlin/eigen-rvv/build-rvv
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("libs/eigen3")
subdirs("libs/eigen2")
subdirs("libs/tensors")
subdirs("libs/BLAS")
subdirs("libs/ublas")
subdirs("libs/gmm")
subdirs("libs/mtl4")
subdirs("libs/blitz")
subdirs("libs/tvmet")
subdirs("libs/STL")
subdirs("libs/blaze")
subdirs("data")
