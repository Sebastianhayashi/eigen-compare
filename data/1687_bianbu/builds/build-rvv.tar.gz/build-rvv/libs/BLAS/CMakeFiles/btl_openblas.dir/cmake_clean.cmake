file(REMOVE_RECURSE
  "CMakeFiles/btl_openblas.dir/main.cpp.o"
  "CMakeFiles/btl_openblas.dir/main.cpp.o.d"
  "btl_openblas"
  "btl_openblas.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_openblas.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
