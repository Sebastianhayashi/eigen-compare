file(REMOVE_RECURSE
  "CMakeFiles/btl_tensor_linear.dir/main_linear.cpp.o"
  "CMakeFiles/btl_tensor_linear.dir/main_linear.cpp.o.d"
  "btl_tensor_linear"
  "btl_tensor_linear.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_tensor_linear.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
