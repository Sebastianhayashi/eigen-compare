file(REMOVE_RECURSE
  "CMakeFiles/btl_tensor_vecmat.dir/main_vecmat.cpp.o"
  "CMakeFiles/btl_tensor_vecmat.dir/main_vecmat.cpp.o.d"
  "btl_tensor_vecmat"
  "btl_tensor_vecmat.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_tensor_vecmat.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
