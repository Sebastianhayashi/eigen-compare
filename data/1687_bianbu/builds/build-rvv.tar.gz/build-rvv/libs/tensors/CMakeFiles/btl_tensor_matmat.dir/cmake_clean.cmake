file(REMOVE_RECURSE
  "CMakeFiles/btl_tensor_matmat.dir/main_matmat.cpp.o"
  "CMakeFiles/btl_tensor_matmat.dir/main_matmat.cpp.o.d"
  "btl_tensor_matmat"
  "btl_tensor_matmat.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_tensor_matmat.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
