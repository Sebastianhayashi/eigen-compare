file(REMOVE_RECURSE
  "CMakeFiles/btl_eigen3_vecmat.dir/main_vecmat.cpp.o"
  "CMakeFiles/btl_eigen3_vecmat.dir/main_vecmat.cpp.o.d"
  "btl_eigen3_vecmat"
  "btl_eigen3_vecmat.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_eigen3_vecmat.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
