# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-rvv/bench/btl/libs/blitz
# Build directory: /home/cody/Sebastianlin/eigen-rvv/build-rvv/libs/blitz
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
