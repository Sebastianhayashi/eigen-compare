# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-rvv/bench/btl/libs/gmm
# Build directory: /home/cody/Sebastianlin/eigen-rvv/build-rvv/libs/gmm
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
