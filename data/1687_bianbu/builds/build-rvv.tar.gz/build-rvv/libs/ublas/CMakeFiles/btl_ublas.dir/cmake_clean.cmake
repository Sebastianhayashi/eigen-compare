file(REMOVE_RECURSE
  "CMakeFiles/btl_ublas.dir/main.cpp.o"
  "CMakeFiles/btl_ublas.dir/main.cpp.o.d"
  "btl_ublas"
  "btl_ublas.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/btl_ublas.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
