# CMake generated Testfile for 
# Source directory: /home/cody/Sebastianlin/eigen-rvv/bench/btl/libs/ublas
# Build directory: /home/cody/Sebastianlin/eigen-rvv/build-rvv/libs/ublas
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(btl_ublas "btl_ublas")
set_tests_properties(btl_ublas PROPERTIES  _BACKTRACE_TRIPLES "/home/cody/Sebastianlin/eigen-rvv/bench/btl/CMakeLists.txt;73;add_test;/home/cody/Sebastianlin/eigen-rvv/bench/btl/libs/ublas/CMakeLists.txt;6;btl_add_bench;/home/cody/Sebastianlin/eigen-rvv/bench/btl/libs/ublas/CMakeLists.txt;0;")
