file(REMOVE_RECURSE
  "CMakeFiles/smooth.dir/smooth.cxx.o"
  "CMakeFiles/smooth.dir/smooth.cxx.o.d"
  "smooth"
  "smooth.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/smooth.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
