file(REMOVE_RECURSE
  "CMakeFiles/main.dir/mean.cxx.o"
  "CMakeFiles/main.dir/mean.cxx.o.d"
  "main"
  "main.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/main.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
