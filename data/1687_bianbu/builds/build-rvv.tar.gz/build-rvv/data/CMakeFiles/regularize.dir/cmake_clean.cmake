file(REMOVE_RECURSE
  "CMakeFiles/regularize.dir/regularize.cxx.o"
  "CMakeFiles/regularize.dir/regularize.cxx.o.d"
  "regularize"
  "regularize.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/regularize.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
